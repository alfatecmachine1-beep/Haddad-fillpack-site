Haddad Fillpack — Static site (Dark theme)
Files: index.html, products.html, about.html, contact.html, assets/styles.css

Deploy (quick):
1. Push these files to your GitHub repository (root).
2. On Vercel: Import Project → select your GitHub repo → Deploy.
3. (Optional) Add your chat widget: replace widget placeholder in index.html with the widget code or the content of haddad-widget.html.

Notes:
- For chat/assistant, add the widget HTML or iframe provided earlier.
- Set up webhook endpoint (WordPress plugin or webhook) to receive leads.
